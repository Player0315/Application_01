////滚动属性设置////
document.addEventListener("touchstart", function (e) {
  document.documentElement.style.overflow = "hidden";
});

document.addEventListener("touchend", function (e) {
  document.documentElement.style.overflow = "auto";
});

////MQTT的接收部分，不可以修改////
var HOST = window.location.origin;
var socket;
let xmlHttpRequest = new XMLHttpRequest();

////对于声音的可视化部分////
let song;
let fft;
let particles = [];
let fruits = [];
let animationTime = 0;

let MAX_NUM_MESSAGES = 2;
let allMessages = new Array();
let font;

////烟花的数组////
let showFireworks = false;
////爱心的数组////
let showLove = false;
let loveParticles = [];

////配置了MQTT 以及加载字体////
function setup() {
  createCanvas(windowWidth, windowHeight);
  setupMqtt();
  angleMode(DEGREES);
  fft = new p5.FFT();
  font = loadFont("assets/Swansea-q3pd.ttf");
  textFont(font);
  textAlign(CENTER, CENTER);
  textSize(48);
  song = loadSound("assets/StartAgain.mp3", loaded);
}

function loaded() {
  song.loop();
}

function draw() {
  background(0);

  //// 爱心特效 ////
  if (showLove) {
    for (let i = 0; i < loveParticles.length; i++) {
      loveParticles[i].draw();
    }
  }

  //此处为文字显示及其属性
  push();
  for (var i = fruits.length - 1; i >= 0; i--) {
    var msg = fruits[i];

    let animationDuration = 2;
    let progress = min(1, animationTime / animationDuration);
    let easing = sin((PI / 2) * progress);
    let scale = 1 + 4 * easing;
    textSize(48 * scale);

    msg.x -= 2; // 控制弹幕移动的速度 每帧 -2

    ////如果消息完全里考屏幕，从数组中移除////
    if (msg.x + textWidth(msg.textMessage) < 0) {
      fruits.splice(i, 1);
    } else {
      fill(random(255), random(255), random(255));
      text(msg.textMessage, msg.x, msg.y);
    }
  }
  pop();

  //此处为粒子的制作
  push();
  stroke(255);
  noFill();
  translate(width / 2, height / 2);
  let wave = fft.waveform();

  for (let t = -1; t <= 1; t += 2) {
    beginShape();
    for (let i = 0; i <= 180; i += 0.5) {
      let index = floor(map(i, 0, 180, 0, wave.length - 1));
      let r = map(wave[index], -1, 1, 150, 350);
      let x = r * sin(i) * t;
      let y = r * cos(i);
      vertex(x, y);
    }
    endShape();
  }

  let p = new Particle();
  particles.push(p);

  for (let i = 0; i < particles.length; i++) {
    particles[i].update();
    particles[i].show();
  }
  pop();

  ////检查showFireworks////
  if (showFireworks) {
    for (let i = 0; i < 100; i++) {
      fill(random(255), random(255), random(255), random(255));
      let x = random(width);
      let y = random(height);
      ellipse(x, y, 10, 10);
    }
    ////让烟花显示一段时间，然后关闭////
    setTimeout(() => {
      showFireworks = false;
    }, 3000);
  }
}

////关键词触发功能////
function addNewMessage(newMessage) {
  console.log("ADDING NE MSG");
  fruits.push(newMessage);

  ////将消息文本转为小写 'toLowerCase()'////
  ////使用 'inclides()' 方法检查是否包含'love'////
  if (newMessage.textMessage.toLowerCase().includes("happy")) {
    console.log("Happy deteced in message");
    ////在这里添加我们的特效////

    showFireworks = true;
  } else if (newMessage.textMessage.toLowerCase().includes("love")) {
    console.log("Love deteced in message");
    ////在这里添加我们的特效////
    showLove = true;
    // 创建爱心粒子
    for (let i = 0; i < 500; i++) {
      // 你可以根据需要调整粒子数量
      let p = new HeartParticle();
      loveParticles.push(p);
    }
    //// 10 秒后关闭爱心特效 ////
    setTimeout(() => {
      showLove = false;
      loveParticles = [];
    }, 10000);
  }

  ////维护 allMessages 数组的长度，确保其长度不会超过 MAX_NUM_MESSAGES 这个设定的最大消息数量////
  if (allMessages.length >= MAX_NUM_MESSAGES) {
    allMessages.shift();
  }
}

function setupMqtt() {
  socket = io.connect(HOST);
  socket.on("mqttMessage", receiveMqtt);
}

function receiveMqtt(data) {
  var topic = data[0];
  var message = data[1];
  console.log("Topic: " + topic + ", message: " + message);
  var newMessage = new ChatMessage(message);
  addNewMessage(newMessage);
}

class Particle {
  constructor() {
    this.pos = p5.Vector.random2D().mult(250);
    this.vel = createVector(0, 0);
    this.acc = this.pos.copy().mult(random(0.0001, 0.00001));
    this.w = random(3, 5);
  }
  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
  }
  show() {
    noStroke();
    fill(255);
    ellipse(this.pos.x, this.pos.y, this.w);
  }
}

class ChatMessage {
  constructor(textMessage) {
    this.textMessage = textMessage + "";
    this.x = windowWidth + 20; // 初始位置在最右边 + 20
    this.y = random(0, windowHeight / 2);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

//// 爱心class ////

class Heart {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
  }

  draw() {
    fill(255, 105, 180); // 粉色
    noStroke();

    // 计算爱心形状的点
    const d = this.size; // 爱心的大小
    const r = d / 2;
    beginShape();
    for (let i = 0; i < 360; i += 1) {
      const radian = radians(i);
      const radius = r * (16 * pow(sin(radian), 3));
      const x = radius * cos(radian);
      const y = radius * sin(radian) - r;
      vertex(this.x + x, this.y + y);
    }
    endShape(CLOSE);
  }
}

class HeartParticle {
  constructor() {
    this.heart = new Heart(random(width), random(height), random(1, 5));
    this.life = 255;
    this.vel = createVector(random(-1, 1), random(-1, 1));
  }

  update() {
    this.heart.x += this.vel.x;
    this.heart.y += this.vel.y;
  }

  draw() {
    this.heart.draw();
    fill(255, 105, 180, this.life); // 粉色
    this.life -= 2.55; // 255/100 = 2.55，100帧后完全透明
  }
}

//// 爱心 class 结束////
