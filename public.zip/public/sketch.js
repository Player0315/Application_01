// 当触摸开始时，禁止页面滚动
document.addEventListener("touchstart", function (e) {
  document.documentElement.style.overflow = "hidden";
});

// 当触摸结束时，允许页面滚动
// document.addEventListener("touchend", function (e) {
// document.documentElement.style.overflow = "auto";
// });

var HOST = window.location.origin;
var socket;
let xmlHttpRequest = new XMLHttpRequest();

// Constants
let MAX_NUM_MESSAGES = 20;

// Variables
let allMessages = new Array();
let myMessageInput;
let font;
let sendButton;
let particles = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  setupMqtt();

  font = loadFont("assets/Swansea-q3pd.ttf");
  textSize(25);

  for (let i = 0; i < 200; i++) {
    particles.push(new Particle());
  }

  /*
1. 创建对话框
2. 设置输入框的X轴和Y轴位置
3. 设置输入框的宽度和高度
4. 设置输入框的字体样式
*/
  //bottomSectionY = windowHeight - bottomSectionHeight;

  myMessageInput = createInput("");
  myMessageInput.position(0.25 * windowWidth, 0.2 * windowHeight);
  myMessageInput.size(0.5 * windowWidth, 0.5 * windowHeight);
  myMessageInput.style("font-size", "30px");
  myMessageInput.style("background-color", "rgba(255, 255, 255)");
  myMessageInput.attribute(
    "placeholder",
    "Please enter your bullet screen here..."
  );
  myMessageInput.style("border", "2px solid rgb(0, 0, 0)");
  myMessageInput.style("color", "rgb(0)");
  myMessageInput.style("border-radius", "10px");
  myMessageInput.style("box-shadow", "-15px -15px black");
  /*
1. 创建按钮
2. 设置按钮的X轴和Y轴位置
3. 设置按钮的宽度和高度
4. 设置交互行为
*/
  sendButton = createButton("LAUNCH");
  sendButton.html("SEND");
  sendButton.size(windowWidth * 0.5, windowHeight * 0.05 + 17);
  sendButton.position(0.25 * windowWidth, 0.8 * windowHeight);
  sendButton.style("border", "2px solid black");
  sendButton.style("border-radius", "10px");
  sendButton.mouseClicked(sendMessage);
  sendButton.style("background-color", "rgb(255,255,255)");
  sendButton.style("color", "black");

  sendButton.style("font-size", "56px");
  sendButton.style("box-shadow", "-15px -15px black");

  //// 为用户创建消息选择器 ////
  let messagesAndPositions = [
    { message: "Hello", x: 0.1 * windowWidth, y: 0.1 * windowHeight },
    { message: "happy", x: 0.2 * windowWidth, y: 0.2 * windowHeight },
    { message: "love", x: 0.3 * windowWidth, y: 0.3 * windowHeight },
    {
      message: "Nice to meet you!",
      x: 0.4 * windowWidth,
      y: 0.4 * windowHeight,
    },
  ]; // 预设消息和它们的位置

  // 为每一个预设消息创建一个按钮
  for (let i = 0; i < messagesAndPositions.length; i++) {
    let messageButton = createButton(messagesAndPositions[i].message);
    messageButton.position(
      messagesAndPositions[i].x,
      messagesAndPositions[i].y
    ); // 设置按钮的位置

    ////对于按钮的个性化设置////
    messageButton.size(0.1 * windowWidth, 0.05 * windowHeight); // 设置按钮的大小
    messageButton.style("background-color", "transparent"); // 设置按钮背景为透明
    //messageButton.style("border", "none"); // 设置按钮边框为无
    messageButton.style("color", "black"); // 设置按钮文本颜色为黑色

    messageButton.mouseClicked(function () {
      // 当用户点击按钮时，发送相应的预设消息

      let postData = JSON.stringify({
        id: 1,
        message: messagesAndPositions[i].message,
      });

      xmlHttpRequest.open("POST", HOST + "/sendMessage", false);

      xmlHttpRequest.setRequestHeader("Content-Type", "application/json");

      xmlHttpRequest.send(postData);

      // Add new message to allMessages array
      var newMessage = new ChatMessage(messagesAndPositions[i].message);

      addNewMessage(newMessage);
    });
  }
}

function draw() {
  /*
1.聊天框上方的颜色
2.聊天框上方的大小
*/

  background(255);

  textSize(32);
  fill(color(random(255), random(255), random(255))); // 生成随机颜色
  textAlign(CENTER, CENTER);
  text("WAO", windowWidth / 2, 50);
  text("SYDNEY'S ONE AND ONLY SUPERCLUB", windowWidth / 2, 100);

  push();
  translate(width / 2, height / 2);
  for (let i = 0; i < particles.length; i++) {
    particles[i].update();
    particles[i].display();
  }
  pop();

  /*
遍历聊天消息，计算每个msg位置，然后在屏幕上显示出来
*/

  for (var i = 0; i < allMessages.length; i++) {
    var index = allMessages.length - 1 - i;
    var msg = allMessages[index];
    var msgY = bottomSectionY - (i + 1) * (msg.h + 5);
    msg.display(msgY);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function addNewMessage(newMessage) {
  console.log("ADDING NE MSG");
  allMessages.push(newMessage);
  if (allMessages.length >= MAX_NUM_MESSAGES) {
    allMessages.shift();
  }
}

function sendMessage() {
  let postData = JSON.stringify({ id: 1, message: myMessageInput.value() });

  xmlHttpRequest.open("POST", HOST + "/sendMessage", false);
  xmlHttpRequest.setRequestHeader("Content-Type", "application/json");
  xmlHttpRequest.send(postData);

  // Add new message to allMessages array
  var newMessage = new ChatMessage(myMessageInput.value());
  addNewMessage(newMessage);

  myMessageInput.value("");
}

function setupMqtt() {
  socket = io.connect(HOST);
  socket.on("mqttMessage", receiveMqtt);
}

function receiveMqtt(data) {
  var topic = data[0];
  var message = data[1];
  console.log("Topic: " + topic + ", message: " + message);

  var newMessage = new ChatMessage(message);
  addNewMessage(newMessage);
}

class ChatMessage {
  constructor(textMessage) {
    this.textMessage = textMessage + "";
    this.h = 68;
  }
}

class Particle {
  constructor() {
    this.x = random(-width / 2, width / 2);
    this.y = random(-height / 2, height / 2);
    this.z = random(width);
    this.speed = random(0.5, 2);
    this.angle = random(0, TWO_PI);
    this.size = map(this.z, 0, width, 8, 16);
    this.growing = true;
  }

  update() {
    this.z -= this.speed * 5;
    if (this.z < 1) {
      this.x = random(-width / 2, width / 2);
      this.y = random(-height / 2, height / 2);
      this.z = width;
      this.angle = random(0, TWO_PI);
      this.size = map(this.z, 0, width, 8, 16);
      this.growing = true;
    }
    if (this.growing) {
      this.size += 0.5;
      if (this.size > map(this.z, 0, width, 16, 32)) {
        this.growing = false;
      }
    } else {
      this.size -= 0.5;
    }
  }

  display() {
    let sx = map(this.x / this.z, 0, 1, 0, width);
    let sy = map(this.y / this.z, 0, 1, 0, height);
    let r = map(this.z, 0, width, this.size, 0);
    fill(0); // 将透明度改为100
    noStroke();
    ellipse(sx, sy, r, r);
  }
}
